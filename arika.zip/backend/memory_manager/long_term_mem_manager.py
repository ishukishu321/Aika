"""
Long-term memory manager.
Handles searching through archived memories using tags with parallel processing.
"""

import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Tuple

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Get the root project directory
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LONG_TERM_FILE = os.path.join(ROOT_DIR, "memory", "long_term_mem.json")


def load_long_term_memories():
    """Load all long-term memory entries."""
    try:
        if not os.path.exists(LONG_TERM_FILE):
            return []
        
        with open(LONG_TERM_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return []


def _match_tags(memory_id: str, memory_entry: Dict, search_tags: Dict) -> Tuple[str, int, Dict]:
    """
    Match search tags against a memory entry's tags.
    Returns: (memory_id, match_score, memory_entry)
    """
    match_score = 0
    memory_tags = memory_entry.get("tags", {})
    
    # Count how many search tags match with memory tags
    for search_tag_key in search_tags.keys():
        if search_tag_key in memory_tags:
            # Higher importance = higher score
            importance = memory_tags[search_tag_key].get("importance", 0)
            match_score += importance
    
    return memory_id, match_score, memory_entry


def _extract_context(content: str, position: int, context_chars: int = 50) -> str:
    """
    Extract context around a position in the content.
    Returns text with `context_chars` before and after the position.
    """
    start = max(0, position - context_chars)
    end = min(len(content), position + context_chars)
    
    return content[start:end].strip()


def search_memories(search_tags: Dict) -> Dict:
    """
    Search long-term memories using tags.
    
    Args:
        search_tags: Dictionary with tag names as keys
        
    Returns:
        Dictionary with matching memory contexts or "Memory not found" message
    """
    
    if not search_tags:
        return {"status": "error", "message": "No tags provided"}
    
    # Load all long-term memories
    memories = load_long_term_memories()
    
    if not memories:
        return {"status": "not_found", "message": "Memory archive is empty"}
    
    # Parallel processing: match tags for each memory
    matches = []
    
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {
            executor.submit(_match_tags, mem["id"], mem, search_tags): mem["id"]
            for mem in memories
        }
        
        for future in as_completed(futures):
            memory_id, match_score, memory_entry = future.result()
            
            if match_score > 0:  # Only keep matches
                matches.append({
                    "id": memory_id,
                    "score": match_score,
                    "entry": memory_entry
                })
    
    if not matches:
        return {"status": "not_found", "message": "No matching memories found"}
    
    # Sort by match score and take top 3
    matches.sort(key=lambda x: x["score"], reverse=True)
    top_matches = matches[:3]
    
    # Extract contexts from top matches
    contexts = []
    
    for match in top_matches:
        entry = match["entry"]
        content = entry.get("content", "")
        tags = entry.get("tags", {})
        
        # Find first matching tag's position
        position = 0
        for tag_key in search_tags.keys():
            if tag_key in tags:
                position = tags[tag_key].get("position", 0)
                break
        
        # Extract context around position
        context_text = _extract_context(content, position, context_chars=50)
        
        # Get importance scores for all matching tags
        importance_scores = {}
        for tag_key in search_tags.keys():
            if tag_key in tags:
                importance_scores[tag_key] = tags[tag_key].get("importance", 0)
        
        contexts.append({
            "id": entry["id"],
            "context": context_text,
            "importance_scores": importance_scores,
            "full_content": content,
            "match_score": match["score"]
        })
    
    return {
        "status": "found",
        "matches": len(contexts),
        "contexts": contexts
    }


def get_memory_context_for_prompt(search_result: Dict) -> str:
    """
    Convert search result into formatted text for prompt builder.
    """
    if search_result["status"] != "found":
        return None
    
    formatted_text = "=== LONG-TERM MEMORY CONTEXT ===\n\n"
    
    for i, context in enumerate(search_result["contexts"], 1):
        formatted_text += f"Memory {i} (ID: {context['id']}):\n"
        formatted_text += f"Context: {context['context']}\n"
        formatted_text += f"Importance Scores: {context['importance_scores']}\n\n"
    
    return formatted_text
