# Memory manager package
