import json
import os

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROFILE_FILE = os.path.join(ROOT_DIR, "memory", "profile.json")


def save_profile(data):
    os.makedirs(os.path.dirname(PROFILE_FILE), exist_ok=True)

    try:
        with open(PROFILE_FILE, "r", encoding="utf-8") as f:
            profile = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        profile = {}

    profile.update(data)

    with open(PROFILE_FILE, "w", encoding="utf-8") as f:
        json.dump(profile, f, indent=4, ensure_ascii=False)

    print("[Profile] Updated Successfully")