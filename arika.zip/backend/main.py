import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from backend.gemini import ask_gemini
from backend.prompt_builder import build_prompt
from backend.parser import process
from backend.command_router import execute
from backend.memory_manager.short_term import save_chat
from backend.memory_manager.long_term_mem_manager import get_memory_context_for_prompt

print("=== Aika AI Assistant ===")
print("Type 'exit' to quit.\n")

while True:

    user = input("You : ").strip()

    if not user:
        continue

    if user.lower() == "exit":
        print("\nArika : Bye! 👋")
        break

    try:
        # Prompt build karo
        prompt = build_prompt(user)

        # Gemini se response lo
        reply = ask_gemini(prompt)

        # Response parse karo
        result = process(reply)

        # Short-term memory me save karo
        # (User aur Assistant dono)
        save_chat(user, result["response"])

        # User ko response dikhao
        print(f"\nArika : {result['response']}\n")

        # Commands execute karo
        long_term_context = None
        for command in result["commands"]:
            command_result = execute(command)
            
            # Check if this was a memory review command
            if command.get("action") == "review_mem" and command_result:
                long_term_context = get_memory_context_for_prompt(command_result)
        
        # If memory was reviewed, send filtered context to LLM
        if long_term_context:
            print("\n[Memory search result processing...]\n")
            
            # 1. YAHAN FIX KIYA HAI: Arika ko explicitly bata rahe hain ki ab command nahi banani hai
            guided_message = f"{user}\n\n[System Note: Memory has been fetched successfully. Answer the user naturally based ONLY on the LONG-TERM MEMORY CONTEXT provided above. DO NOT output any <COMMAND> blocks.]"
            
            # Build new prompt with long-term context
            memory_prompt = build_prompt(guided_message, long_term_context=long_term_context)
            
            # Get LLM response based on memory context
            memory_reply = ask_gemini(memory_prompt)
            
            # Parse and display
            memory_result = process(memory_reply)
            
            print(f"Arika (from memory): {memory_result['response']}\n")
            
            # Save this exchange too (User ka original input save hoga)
            save_chat(f"[Memory Review] {user}", memory_result["response"])

    except Exception as e:
        print(f"\n[Error] {e}\n")