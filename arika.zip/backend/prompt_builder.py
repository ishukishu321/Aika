from backend.memory_manager.short_term import get_recent_messages
from backend.memory_manager.summary_maker import get_recent_summaries


def build_prompt(user_message: str, long_term_context: str = None) -> str:
    """
    Builds the conversation prompt for Gemini.
    
    Args:
        user_message: The current user message
        long_term_context: Optional long-term memory context (from memory search)
    """

    messages = get_recent_messages()
    summaries = get_recent_summaries()

    conversation = ""
    summary_context = ""
    long_term_section = ""

    for summary in summaries:
        summary_context += f"Summary {summary['id']}: {summary['summary']}\n\n"

    for msg in messages:
        conversation += (
            f"Time: {msg['timestamp']}\n"
            f"User: {msg['user']}\n"
            f"Arika: {msg['arika']}\n\n"
        )

    # Add long-term memory context if provided
    if long_term_context:
        long_term_section = f"""
==============================
LONG-TERM MEMORY ARCHIVE
==============================

{long_term_context}
"""

    prompt = f"""
==============================
CONVERSATION SUMMARIES
==============================

{summary_context}{long_term_section}

==============================
RECENT CONVERSATION
==============================

{conversation}

==============================
CURRENT USER MESSAGE
==============================

User: {user_message}
"""

    return prompt