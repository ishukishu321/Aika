import json
import os
from google import genai

# Get the directory where this script is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
API_KEY_FILE = os.path.join(SCRIPT_DIR, "memory", "api_key.txt")
SYSTEM_INSTRUCTION_PATH = os.path.join(SCRIPT_DIR, "system_instruction.txt")

_client = None
_BASE_SYSTEM_INSTRUCTION = None


def _load_system_instruction():
    global _BASE_SYSTEM_INSTRUCTION
    if _BASE_SYSTEM_INSTRUCTION is None:
        try:
            with open(SYSTEM_INSTRUCTION_PATH, "r", encoding="utf-8") as f:
                _BASE_SYSTEM_INSTRUCTION = f.read()
        except FileNotFoundError:
            _BASE_SYSTEM_INSTRUCTION = "You are a helpful assistant."
    return _BASE_SYSTEM_INSTRUCTION


def _load_api_key():
    api_key = os.getenv("GEMINI_API_KEY")
    if api_key and api_key.strip():
        return api_key.strip()

    if os.path.exists(API_KEY_FILE):
        try:
            with open(API_KEY_FILE, "r", encoding="utf-8") as f:
                stored_key = f.read().strip()
                if stored_key:
                    return stored_key
        except Exception:
            pass

    return None


def _save_api_key(api_key: str):
    os.makedirs(os.path.dirname(API_KEY_FILE), exist_ok=True)
    with open(API_KEY_FILE, "w", encoding="utf-8") as f:
        f.write(api_key.strip())


def _get_api_key():
    api_key = _load_api_key()
    if api_key:
        return api_key

    api_key = input("Enter your Gemini API key: ").strip()
    if not api_key:
        raise ValueError("Gemini API key is required.")

    _save_api_key(api_key)
    print(f"Saved Gemini API key to {API_KEY_FILE}")
    return api_key


def _get_client():
    global _client
    if _client is None:
        api_key = _get_api_key()
        _client = genai.Client(api_key=api_key)
    return _client


def ask_gemini(prompt: str, model: str = "gemini-3.1-flash-lite") -> str:
    # Load system instruction
    base_system_instruction = _load_system_instruction()
    
    # Load profile
    PROFILE_PATH = os.path.join(SCRIPT_DIR, "memory", "profile.json")
    try:
        with open(PROFILE_PATH, "r", encoding="utf-8") as f:
            profile = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        profile = {}

    # Combine system instruction + profile
    system_instruction = f"""
{base_system_instruction}

==============================
KNOWN USER INFORMATION
==============================

{json.dumps(profile, indent=4)}
"""

    response = _get_client().models.generate_content(
        model=model,
        contents=prompt,
        config={
            "system_instruction": system_instruction
        }
    )

    return response.text