from backend.memory_manager.profile import save_profile
from backend.memory_manager.long_term_mem_manager import search_memories

def execute(command):

    action = command.get("action")
    data = command.get("data", {})

    if action == "save_profile":
        save_profile(data)

    elif action == "review_mem":
        # Extract tags from data
        tags = data
        
        # Import and call long_term_mem_manager
        try:
            from backend.memory_manager.long_term_mem_manager import search_memories
            result = search_memories(tags)
            return result
        except Exception as e:
            print(f"[Command Router] Error searching memories: {e}")
            return {"status": "error", "message": str(e)}

    else:
        print(f"[Command Router] Unknown action: {action}")