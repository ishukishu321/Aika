import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from flask import Flask, render_template, request, jsonify, url_for
import asyncio
import edge_tts
import time
import re

from backend.gemini import ask_gemini
from backend.prompt_builder import build_prompt
from backend.parser import process
from backend.command_router import execute
from backend.memory_manager.short_term import save_chat, get_recent_messages
from backend.memory_manager.long_term_mem_manager import get_memory_context_for_prompt

FRONTEND_DIR = Path(__file__).resolve().parent
app = Flask(__name__, template_folder=str(FRONTEND_DIR), static_folder=str(FRONTEND_DIR / "static"))
AUDIO_DIR = os.path.join(app.root_path, 'static', 'audio')
os.makedirs(AUDIO_DIR, exist_ok=True)

def chunk_text(text, max_length=150):
    """Splits text into chunks based on punctuation to avoid breaking words."""
    sentences = re.split(r'(?<=[.!?\n])\s+', text)
    chunks = []
    current_chunk = ""
    
    for sentence in sentences:
        if len(current_chunk) + len(sentence) < max_length:
            current_chunk += " " + sentence
        else:
            if current_chunk:
                chunks.append(current_chunk.strip())
            current_chunk = sentence
            
    if current_chunk:
        chunks.append(current_chunk.strip())
    return chunks

async def delayed_generate(text, filename, delay_sec):
    """Generates audio with a slight delay to avoid TTS rate limits."""
    await asyncio.sleep(delay_sec)
    voice = "en-US-AvaNeural" 
    communicate = edge_tts.Communicate(text, voice)
    try:
        await communicate.save(os.path.join(AUDIO_DIR, filename))
        return filename
    except Exception as e:
        print(f"[TTS Error in chunk] {e}")
        return None

async def generate_audio_chunks(text):
    """Processes multiple text chunks in parallel."""
    chunks = chunk_text(text)
    tasks = []
    filenames = []
    
    for i, chunk in enumerate(chunks):
        if not chunk.strip():
            continue
        filename = f"resp_{int(time.time())}_{i}.mp3"
        filenames.append(filename)
        # 0.2s stagger gap instead of 1s to keep it fast!
        tasks.append(delayed_generate(chunk, filename, delay_sec=i * 0.2))
        
    await asyncio.gather(*tasks)
    return filenames

@app.route("/")
def index():
    conversation = get_recent_messages(limit=10)
    return render_template("index.html", conversation=conversation)

@app.route("/api/chat", methods=["POST"])
def api_chat():
    data = request.json
    user_message = data.get("user_message", "").strip()
    
    if not user_message:
        return jsonify({"error": "Empty message"}), 400

    prompt = build_prompt(user_message)
    reply = ask_gemini(prompt)
    result = process(reply)
    save_chat(user_message, result["response"])
    
    long_term_context = None
    for command in result["commands"]:
        command_result = execute(command)
        if command.get("action") == "review_mem" and command_result:
            long_term_context = get_memory_context_for_prompt(command_result)
            
    if long_term_context:
        guided_message = f"{user_message}\n\n[System Note: Memory has been fetched successfully. Answer the user naturally based ONLY on the LONG-TERM MEMORY CONTEXT provided above. DO NOT output any <COMMAND> blocks.]"
        memory_prompt = build_prompt(guided_message, long_term_context=long_term_context)
        memory_reply = ask_gemini(memory_prompt)
        memory_result = process(memory_reply)
        response_text = memory_result["response"]
        save_chat(f"[Memory Review] {user_message}", memory_result["response"])
    else:
        response_text = result["response"]
        
    # --- Parallel Audio Generation ---
    audio_urls = []
    try:
        filenames = asyncio.run(generate_audio_chunks(response_text))
        audio_urls = [url_for('static', filename=f'audio/{fname}') for fname in filenames if fname]
    except Exception as e:
        print(f"[TTS Master Error] {e}")

    return jsonify({
        "response": response_text,
        "audio_urls": audio_urls
    })

if __name__ == "__main__":
    # host='0.0.0.0' allow karta hai Wi-Fi ki dusri devices ko connect karne ke liye
    # ssl_context='adhoc' ek temporary HTTPS connection banayega taaki phone ka mic chale!
    app.run(host="0.0.0.0", port=5000, debug=True, ssl_context="adhoc")